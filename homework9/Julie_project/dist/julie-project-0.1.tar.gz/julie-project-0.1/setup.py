from setuptools import setup, find_packages


setup(
    name='julie-project',
    version='0.1',
    author="Julie",
    author_email='email@example.com',
    packages=find_packages(),
    url='https://github.com/JulieYatskevich/DZ-4',
    install_requires=[
          'Django==4.0.4',
      ],

)